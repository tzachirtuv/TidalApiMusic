﻿using System;
namespace TidalInfra.DTO
{
    public class DeleteDto
    {
        public DeleteDto()
        {
        }
    }
}
