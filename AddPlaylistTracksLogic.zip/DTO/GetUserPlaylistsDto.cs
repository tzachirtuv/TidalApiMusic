﻿using System;
namespace TidalInfra.DTO
{
    public class GetUserPlaylistsDto
    {
        public GetUserPlaylistsDto()
        {
        }
    }
}
