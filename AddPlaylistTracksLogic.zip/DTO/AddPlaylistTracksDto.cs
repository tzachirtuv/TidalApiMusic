﻿using System;
namespace TidalInfra.DTO
{
    public class AddPlaylistTracksDto
    {
        public AddPlaylistTracksDto()
        {
        }
    }
}
