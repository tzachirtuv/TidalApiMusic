﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TidalInfra.Log
{
    public interface ILogger
    {
        void WriteInfo(string message);
        void Writewarrning(string message);
    }

    public enum LogLevel
    {
        Info,
        Warrning
    }
}
