﻿namespace TidalInfra.Log
{
    public abstract class BaseLogger : ILogger
    {
        public abstract void Write(LogLevel logLevel,string message);

        public void WriteInfo(string message)
        {
            Write(LogLevel.Info, message);
        }

        public void Writewarrning(string message)
        {
            Write(LogLevel.Warrning, message);
        }
    }
}
