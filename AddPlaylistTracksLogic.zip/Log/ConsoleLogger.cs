﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TidalInfra.Log
{
    public class ConsoleLogger : BaseLogger
    {
        public override void Write(LogLevel logLevel, string message)
        {
            Console.WriteLine($"{logLevel} : {message}");
        }
    }
}
